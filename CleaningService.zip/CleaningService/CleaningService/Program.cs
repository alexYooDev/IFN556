﻿internal class Program
{
    private static void Main(string[] args)

    
    {
        // Task 1

        const string WELCOME_MSG1 = "Best. Cheapest Cleaning Service";
        const string WELCOME_MSG2 = "Written by ";

        const string surname = "Yoo";
        const string firstName = "Hwanik";
        const string studentId = "N12159069";

        const string BORDER = "*$";

        for (int i = 0; i < 28; ++i)
        {
            Console.Write(BORDER);
            
        }

        Console.WriteLine("");
        Console.WriteLine("{0,-11} {1,-5} {0,12}", BORDER,WELCOME_MSG1);
        Console.WriteLine("{0,-9} {1,-5} {2} {3} {4} 3.5 {0,9}", BORDER, WELCOME_MSG2, firstName, surname, studentId);

        for (int j = 0; j < 28; ++j)
        {
            Console.Write(BORDER);

        }

        Console.WriteLine();
        Console.WriteLine();


        // Task 2

        Console.Write("Please enter your hours required for the service: ");

        double hourOfService = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine();


        // Task 3

        const double MIN_CHARGE = 100.00;
        const double CHARGE_PER_HOUR = 50.00;

        double serviceCost = hourOfService * CHARGE_PER_HOUR;


        // Task 4

        if (serviceCost < MIN_CHARGE)
        {
            Console.WriteLine("The cost of your service is our minimum charge! : {0}", MIN_CHARGE.ToString("C2"));
        } else
        {
            Console.WriteLine("The cost of your service is : {0}", serviceCost.ToString("C2"));
        }

        Console.WriteLine();


        // Task 5

        double sumOfJobs = 0d;

        for (int job = 0; job < 5; ++job)
        {
            Console.Write("Please enter 5 different duration of the jobs in hour (ex: 4.5): ");
            double durationOfJob = Convert.ToDouble(Console.ReadLine());

            if (durationOfJob > 3)
            {
                sumOfJobs += durationOfJob;
            }
        }

        Console.WriteLine();
        Console.WriteLine();
        
        Console.WriteLine("Here is your total hour of jobs longer than 3 hours: {0} hours", sumOfJobs);
    }
}